(FileAst "function.adap.h" Begin)
(FileAst "function.adap.h" End)
