package ast.scanner;

public class NumToken extends StringToken {
    public NumToken(String _num) {
        super(_num);
    }
}
