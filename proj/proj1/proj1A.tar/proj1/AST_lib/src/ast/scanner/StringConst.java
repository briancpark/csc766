package ast.scanner;

public class StringConst extends StringToken {
    public StringConst(String str) {
        super(str);
    }
}
