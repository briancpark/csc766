package ast.scanner;

public class IDToken extends StringToken {
    public IDToken(String str) {
        super(str);
    }
}

