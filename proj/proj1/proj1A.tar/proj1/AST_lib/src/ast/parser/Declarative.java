/*
 * Declarative.java
 *
 * Created on October 8, 2001, 1:50 PM
 */

package ast.parser;

/**
 * @author administrator
 */
public interface Declarative {

}
