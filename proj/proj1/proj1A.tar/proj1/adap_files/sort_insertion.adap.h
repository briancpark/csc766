(FileAst "sort_insertion.adap.h" Begin)
(FileAst "sort_insertion.adap.h" End)
