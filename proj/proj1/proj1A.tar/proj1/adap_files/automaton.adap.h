(FileAst "automaton.adap.h" Begin)
(FileAst "automaton.adap.h" End)
