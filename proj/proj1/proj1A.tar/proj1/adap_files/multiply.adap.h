(FileAst "multiply.adap.h" Begin)
(FileAst "multiply.adap.h" End)
