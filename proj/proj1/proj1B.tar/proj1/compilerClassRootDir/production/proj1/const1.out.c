/* FileAst "const1.adap" Begin */
int main() ;

int main() {
      {
      int A[20];
      int i;
      i = 2;
      A[10]  = ((i + 2) + 4);
      printf("%d\n", (A[10]  + 2));
      }
      return 0;
   L1:;
}
/* FileAst "const1.adap" End */
