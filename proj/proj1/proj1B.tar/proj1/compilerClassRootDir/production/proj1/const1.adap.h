(FileAst "const1.adap.h" Begin)
(FileAst "const1.adap.h" End)
