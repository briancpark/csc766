package ast.scanner;

public class RWordToken extends StringToken {
    public RWordToken(String str) {
        super(str);
    }
}
