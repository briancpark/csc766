package ast.scanner;

public class SymToken extends StringToken {
    public SymToken(String str) {
        super(str);
    }
}

