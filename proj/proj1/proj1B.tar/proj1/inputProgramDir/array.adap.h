(FileAst "array.adap.h" Begin)
(FileAst "array.adap.h" End)
