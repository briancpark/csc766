(FileAst "mandel.adap.h" Begin)
(FileAst "mandel.adap.h" End)
